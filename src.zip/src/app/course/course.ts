export interface COURSE {
    couresId:number,
    courseName:string,
    courseDescription:string,
    courseDuration:number,
    courseStatus:string
}
  