export class Constants {
    public static readonly USER_KEY: string='';
}
