export class Courseenquiry {
        cEnquiryId:number|undefined
        name:string|undefined
        email:string|undefined
        phone:number|undefined
        qualification:string|undefined
        age:string|undefined
        testScore:number|undefined
        enquityStatus:string | undefined
        enquiryDate:any|undefined
        courseId:number|undefined

}
