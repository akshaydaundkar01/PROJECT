export class Course {
     couresId:number|undefined;
     courseName:string|undefined;
     courseDescription:string|undefined;
     courseDuration:number|undefined;
     courseStatus:string|undefined;

     
}
