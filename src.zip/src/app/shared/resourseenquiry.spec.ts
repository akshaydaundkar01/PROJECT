import { Resourseenquiry } from './resourseenquiry';

describe('Resourseenquiry', () => {
  it('should create an instance', () => {
    expect(new Resourseenquiry()).toBeTruthy();
  });
});
