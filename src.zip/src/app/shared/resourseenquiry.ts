export class Resourseenquiry {
    cResourceId:number|undefined
        name:string|undefined
        email:string|undefined
        phone:number|undefined
        enquiryDate:any|undefined
        resourceId:number|undefined
}
