export class updateStatus {
    EnquiryStatus:string="";
    Id:number=0;
}