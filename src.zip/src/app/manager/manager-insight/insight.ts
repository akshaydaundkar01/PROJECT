export class PageVisits {
    public Page: String;
    public Views: number;
     constructor(page: String,views: number){
         this.Page=page;
         this.Views=views;
     }
   }