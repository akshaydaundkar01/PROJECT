﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainLayer.Models
{
    public class Visit
    {
        [Key]
        public int VisitId { get; set; } = 0;
/*        public String Page { get; set; }
*//*        public DateTime Day { get; set; } = DateTime.Now;
*//*        public int Views { get; set; } = 1;
*/
        public string CustName { get; set; }

        [Required]
        public string ContactPerson { get; set; }

        [Required]
        public string ContactNo { get; set; }

        [Required]
        public string InterestProduct { get; set; }

        [Required]
        public string VisitSubject { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]

        public DateTime VisitDate { get; set; } = DateTime.Now;

        public bool IsDisabled { get; set; }

        public bool IsDeleted { get; set; }
    }
}
