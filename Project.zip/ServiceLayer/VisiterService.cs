﻿using DomainLayer.Models;
using RepositoryLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceLayer
{
    public class VisiterService : IVisiter
    {
        private readonly AppDBContext _dbContext;
        public VisiterService(AppDBContext dbContext)
        {
            this._dbContext = dbContext;
        }
        
        public string AddCourse(Visiter course)
        {
            try
            {
                this._dbContext.Courses.Add(course);
                this._dbContext.SaveChanges();
                return "Visiter Added Successfully";
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
        }

        public List<Visiter> GetAllCourses()
        {
            return this._dbContext.Courses.ToList();
        }

        public Visiter GetSingleCourse(long id)
        {
            return this._dbContext.Courses.Where(x => x.visitId == id).FirstOrDefault();
        }

        public string RemoveCourse(int id)
        {
            try
            {
                var C = this._dbContext.Courses.Find(id);
                this._dbContext.Remove(C);
                this._dbContext.SaveChanges();
                return "Visiter Deleted Successfully";
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
        }


        public string UpdateCourse(Visiter course)
        {
            try
            {
                var C = this._dbContext.Courses.Find(course.visitId);
                if (C != null)
                {
                    C.CustName = course.CustName;
                    C.ContactPerson = course.ContactPerson;
                    C.ContactNo = course.ContactNo;
                    C.InterestProduct = course.InterestProduct;
                    C.VisitSubject = course.VisitSubject;
                    C.Description = course.Description;
                    C.dateTime = course.dateTime;
                    C.IsDisabled = course.IsDisabled;
                    C.IsDeleted = course.IsDeleted;



                    this._dbContext.SaveChanges();
                    return "Course Updated Successfully";
                }
                else
                    return "No Record Found";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }
}
